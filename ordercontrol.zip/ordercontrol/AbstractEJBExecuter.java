package jp.co.nttcom.service.ordercontrol;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jp.co.nttcom.business.exception.SysifException;

public abstract class AbstractEJBExecuter<T> {

    /**
     * ログ
     */
    private static Logger log = LoggerFactory.getLogger("access");

    /**
     * <p>[概 要] EJBインタフェース実行共通処理。</p>
     * 
     */
    public T execute() throws SysifException {
        try {
            log.info("Get Order control EJB 開始");
            T outVo = getEJBObjAndCall();
            log.info("Get Order control EJB 終了");
            return outVo;
        } catch (Exception e) {
            return null;
        }
    }

    abstract protected T getEJBObjAndCall() throws Exception;
}
