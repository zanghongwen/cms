package jp.co.nttcom.service.ordercontrol;

import jp.co.nttcom.business.epf.adapter.sod.inbnd.setsubirennkei.ejb.ICnvEsbSodEjbSetsubirennkeiRcvBean;

public interface OrderControlEJBInterfaces {
    public ICnvEsbSodEjbSetsubirennkeiRcvBean getICnvEsbSodEjbSetsubirennkeiRcvBean();
}
