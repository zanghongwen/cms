package jp.co.nttcom.service.ordercontrol.ejb;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import jp.co.nttcom.dto.SoEjbEntryVo;
import jp.co.nttcom.dto.SoEjbResultVo;
import jp.co.nttcom.service.ordercontrol.AbstractEJBExecuter;
import jp.co.nttcom.service.ordercontrol.OrderControlEJBInterfaces;

@RequestScoped
public class CnvEsbSodEjbSetsubirennkeiRcvBeanExecuter extends AbstractEJBExecuter<SoEjbResultVo> {

    @Inject
    OrderControlEJBInterfaces interTest;
    private SoEjbEntryVo soEjbEntryVo;

    @Override
    protected SoEjbResultVo getEJBObjAndCall() throws Exception {
        return interTest.getICnvEsbSodEjbSetsubirennkeiRcvBean().get_method(soEjbEntryVo);
    }

    public SoEjbEntryVo getSoEjbEntryVo() {
        return soEjbEntryVo;
    }

    public void setSoEjbEntryVo(SoEjbEntryVo soEjbEntryVo) {
        this.soEjbEntryVo = soEjbEntryVo;
    }
}
