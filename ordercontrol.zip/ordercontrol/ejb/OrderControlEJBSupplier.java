package jp.co.nttcom.service.ordercontrol.ejb;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.xmlbeans.XmlObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jp.co.nttcom.business.epf.adapter.sod.inbnd.setsubirennkei.ejb.ICnvEsbSodEjbSetsubirennkeiRcvBean;
import jp.co.nttcom.common.CommonUtil;
import jp.co.nttcom.dto.SoEjbEntryVo;
import jp.co.nttcom.service.ordercontrol.AbstractEJBExecuter;
import jp.co.nttcom.service.ordercontrol.OrderControlEJBInterfaces;
import jp.co.nttcom.util.PropertiesUtil;

@RequestScoped
public class OrderControlEJBSupplier implements OrderControlEJBInterfaces, Serializable {

    private static final long serialVersionUID = 1618103424712172668L;

    /**
     * ログ
     */
    private static Logger logger = LoggerFactory.getLogger("access");

    private static String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";
    private static final String PROP_FILE_NAME = "ServerCommunication";

    public static final String ORDER_CONTROL_PROVIDER_URL =
            "COMMONEJBRENKEI_ORDER_CONTROL_PROVIDER_URL";


    /**
     * オーダ制御:オーダドメイン JNDI
     */
    private static String CnvEsbSodEjbSetsubirennkeiRcv =
            "epf.adapter.sod.inbnd.setsubirennkei.ejb.CnvEsbSodEjbSetsubirennkeiRcv";

    /**
     * オーダ制御:オーダドメイン インタフェース
     */
    private ICnvEsbSodEjbSetsubirennkeiRcvBean iCnvEsbSodEjbSetsubirennkeiRcvBean;
    private HashMap<String, Object> orderControlEJBMap = new HashMap<>();
    PropertiesUtil propertiesUtil = PropertiesUtil.getInstance(PROP_FILE_NAME);



    @PostConstruct
    private void init() {
        logger.info("オーダ制御EJBインタフェース初期化開始");

        // プロパティファイルより接続情報を取得し、EJBクライアントオブジェクトに設定する。
        Properties env = new Properties();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        env.put(Context.PROVIDER_URL,
                propertiesUtil.getValue(ORDER_CONTROL_PROVIDER_URL));
        logger.info("オーダ制御連携URL: " + propertiesUtil.getValue(ORDER_CONTROL_PROVIDER_URL));
        try {
            // オーダ制御:オーダドメイン EJBオブジェクト取得
            iCnvEsbSodEjbSetsubirennkeiRcvBean =
                    (ICnvEsbSodEjbSetsubirennkeiRcvBean) new InitialContext(env)
                            .lookup(CnvEsbSodEjbSetsubirennkeiRcv);
        } catch (NamingException e) {
            logger.error("EJBオブジェクト取得エラー" + e);

        }

        // orderControlEJBMap.put(
        // iCnvEsbSodEjbSetsubirennkeiRcvBean.getClass().getSimpleName(),
        // iCnvEsbSodEjbSetsubirennkeiRcvBean);

        logger.info("オーダ制御EJBインタフェース初期化完了");
    }

    @Inject
    CnvEsbSodEjbSetsubirennkeiRcvBeanExecuter cnvEsbSodEjbSetsubirennkeiRcvBeanExecuter;

    public AbstractEJBExecuter getEJBExecuterByEventId(String msgId, String bpId,
            String eventId, XmlObject xmlObject) {

        switch (eventId) {
            case "10000":
            case "10010":
                // オーダ制御連携VO（送信）に連携情報を設定する。
                SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
                String sysTime = formatter.format(new Date());
                SoEjbEntryVo soEjbEntryVo = new SoEjbEntryVo();
                soEjbEntryVo.setEvent_id(new Long(eventId));// イベントID
                soEjbEntryVo.setXmlObject(xmlObject);// XMLオブジェクト
                soEjbEntryVo.setMessage_uuid(msgId);// XMLを識別するID
                soEjbEntryVo.setSend_time(sysTime);// システム日時（年月日時分秒ミリ秒）
                soEjbEntryVo.setReceipt_uuid(bpId);// 設備のXMLを識別するID
                cnvEsbSodEjbSetsubirennkeiRcvBeanExecuter.setSoEjbEntryVo(soEjbEntryVo);
                return cnvEsbSodEjbSetsubirennkeiRcvBeanExecuter;
            default:
                break;
        }
        return null;
    }



    public ICnvEsbSodEjbSetsubirennkeiRcvBean getICnvEsbSodEjbSetsubirennkeiRcvBean() {
        if (iCnvEsbSodEjbSetsubirennkeiRcvBean == null) {
            iCnvEsbSodEjbSetsubirennkeiRcvBean =
                    (ICnvEsbSodEjbSetsubirennkeiRcvBean) getOrderControlEJB(
                            ORDER_CONTROL_PROVIDER_URL, CnvEsbSodEjbSetsubirennkeiRcv);
        }
        return iCnvEsbSodEjbSetsubirennkeiRcvBean;
    }

    public Object getOrderControlEJB(String URL, String JNDI) {
        Properties env = new Properties();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        env.put(Context.PROVIDER_URL, URL);
        try {
            return new InitialContext(env).lookup(JNDI);
        } catch (NamingException e) {
            logger.error("EJBオブジェクト取得エラー" + e);
        }
        return null;
    }

}
